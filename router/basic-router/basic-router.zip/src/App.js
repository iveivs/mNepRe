import { Route, Routes, Link } from "react-router-dom";

import Home from "./Pages/HomePage";
import About from "./Pages/AboutPage";
import Blog from "./Pages/BlogPage";
import NotFound from "./Pages/NotFoundPage";
function App() {
  return (
    <>
      <header className="App-header">
          <Link to="/">Home</Link>
          <Link to="/posts">Blog</Link>
          <Link to="/about">About</Link>
        </header>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/posts" element={<Blog />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      <div>
        <h1>Get started router</h1>
      </div>
    </>
  );
}

export default App;
