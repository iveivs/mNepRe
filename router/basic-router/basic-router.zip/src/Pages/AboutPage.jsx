const About = () => {
    return ( 
        <div className="container">
            <h1>About</h1>
            <p>About Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
        </div>
     );
}
 
export default About;