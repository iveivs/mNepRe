const Home = () => {
    return ( 
        <div className="container">
            <h1>Home</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae, ullam</p>
        </div>
     );
}
 
export default Home;